package testCases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import pom.DragPage;
import pom.HomePage;
import pom.SignUpPage;
import pom.swipePage;

public class HomePageTests extends BaseTest {

	/**
	 * Provides test data for successful sign-up tests from a JSON file.
	 */
	@DataProvider(name = "signupData")
	public Object[][] provideData() throws IOException {
		// Load user sign-up data from a JSON file
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "\\TestData\\signupData.json");
		// Prepare the test data array
		Object[][] testData = new Object[data.size()][4];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("email");
			testData[i][1] = row.get("password");
			testData[i][2] = row.get("confirmpassword");
			testData[i][3] = row.get("signupsuccessmsg");
		}
		return testData;
	}

	@DataProvider(name = "loginData")
	public Object[][] provideLoginData() throws IOException {
		// Load user login data from a JSON file
		List<HashMap<String, String>> data = getJsonData(System.getProperty("user.dir") + "\\TestData\\loginData.json");
		// Prepare the test data array
		Object[][] testData = new Object[data.size()][3];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("email");
			testData[i][1] = row.get("password");
			testData[i][2] = row.get("loginSuccessfullmsg");
		}
		return testData;
	}

	@Test(priority = 0, dataProvider = "signupData")
	public void signupTest(String email, String password, String confirmPassword, String successfullmsg) {
		SignUpPage supg = new SignUpPage(driver);
		HomePage hmpg = new HomePage(driver);
		hmpg.clickLogin();
		hmpg.clickSignUp();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(hmpg.isSignUpOptionDisplyed()).isTrue();
		});
		
		// // Assuming that hmpg.isSignUpOptionDisplyed() returns a boolean value indicating whether the sign-up option is displayed.

		//Assert.assertTrue(hmpg.isSignUpOptionDisplyed(), "Assertion failed: Sign-up option is not displayed.");


		supg.sendEmail(email);
		supg.sendPswd(password);
		supg.sendCpswd(confirmPassword);

		supg.clickSignUpBtn();

		String expected = supg.getTextSuccessMsg();
		System.out.println(expected);
		String actual = successfullmsg;
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
		});

		// supg.clickOK();

	}

	@Test(priority = 1, dataProvider = "loginData")
	public void signupTest(String email, String password, String successmsg) {
		HomePage hmpg = new HomePage(driver);
		hmpg.clickLogin();
		hmpg.sendEmail(email);
		hmpg.sendPswd(password);
		hmpg.clickLoginBtn();

		String expected = hmpg.getLgnscsMsg();
		String actual = successmsg;
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
		});

		// hmpg.clickOk();

	}

	@Test(priority = 2)
	public void dragTest() {
		DragPage drg = new DragPage(driver);
		drg.clickDrag();
		drg.dragElement1();
		drg.dragElement2();
		drg.dragElement3();
		drg.dragElement4();
		drg.dragElement5();
		drg.dragElement6();
		drg.dragElement7();
		drg.dragElement8();
		drg.dragElement9();

		// Verify the visibility of congratulations message andyou made it displayed
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(drg.cngrtsDisplayed()).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(drg.youMadeItDisplayed()).isTrue();
		});
	}

	@Test
	public void swipeTest() {
		swipePage swppg=new swipePage(driver);
		swppg.clickSwipe();
		//swppg.swipeOnce("left");
		swppg.swipeOne();
		swppg.swipeOne();
		
		
	}
}
