package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class SignUpPage  extends AndroidActions {
	AndroidDriver driver;

	public SignUpPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-email\"]")
	private WebElement email_signup;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-password\"]")
	private WebElement pswd_signup;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-repeat-password\"]")
	private WebElement cpswd_signup;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-SIGN UP\"]/android.view.ViewGroup")
	private WebElement signup_btn;
	
	@AndroidFindBy(id="android:id/message")
	private WebElement successmsg;
	
	@AndroidFindBy(id="android:id/button1")
	private WebElement ok;
	
	public void sendEmail(String email) {
		email_signup.sendKeys(email);
	}
	
	public void sendPswd(String pword) {
		pswd_signup.sendKeys(pword);
	}

	public void sendCpswd(String cpword) {
		cpswd_signup.sendKeys(cpword);
	}
	
	public void clickSignUpBtn() {
		signup_btn.click();
	}
	
	public String getTextSuccessMsg() {
		return successmsg.getText();
	}
	
	public void clickOK() {
		ok.click();
	}

}
