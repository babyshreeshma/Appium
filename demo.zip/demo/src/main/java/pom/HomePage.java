package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class HomePage extends AndroidActions {
	AndroidDriver driver;

	public HomePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Login\")")
	private WebElement login;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-sign-up-container\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement signup;
	
	@AndroidFindBy(xpath= "//android.widget.EditText[@content-desc=\"input-email\"]")
	private WebElement email_lgn;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-password\"]")
	private WebElement pswd_lgn;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-LOGIN\"]/android.view.ViewGroup")
	private WebElement loginbtn;
	
	@AndroidFindBy(id="android:id/message")
	private WebElement lgnsuccessmsg;
	
	@AndroidFindBy(id="android:id/button1")
	private WebElement ok;
	
	
	
	
	public void clickLogin() {
		login.click();
	}
	
	public void clickSignUp() {
		signup.click();
	}
	
	public boolean isSignUpOptionDisplyed() {
		return signup.isDisplayed();
	}
	
	public void sendEmail(String emailTolgn) {
		email_lgn.sendKeys(emailTolgn);
		
	}
	
	public void sendPswd(String pswd) {
		pswd_lgn.sendKeys(pswd);
	}
	
	public void clickLoginBtn() {
		loginbtn.click();
	}
	
	public String getLgnscsMsg() {
		return lgnsuccessmsg.getText();
		}
	
	public void clickOk() {
		ok.click();
	}
	

}
