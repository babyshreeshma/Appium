package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class swipePage extends AndroidActions {
	AndroidDriver driver;

	public swipePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}
	
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Swipe\")")
	private WebElement swipe;
	
	@AndroidFindBy(xpath="(//android.view.ViewGroup[@content-desc=\"card\"])[1]/android.widget.TextView")
	private WebElement swipe_one;
	
	public void clickSwipe() {
		swipe.click();
	}
	
	public void swipeOnce(String direction) {
		swipeAction(swipe_one,direction);
	}
	
	public void swipeOne() {
		swipeLeft(swipe_one);
	}
}
