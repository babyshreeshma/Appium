package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class DragPage extends AndroidActions {
	AndroidDriver driver;

	public DragPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}
	
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Drag\")")
	private WebElement drag;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-l1\"]/android.widget.ImageView")
	private WebElement ele_one_one;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-c1\"]/android.widget.ImageView")
	private WebElement ele_one_two;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-r1\"]/android.widget.ImageView")
	private WebElement ele_one_three;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-l2\"]/android.widget.ImageView")
	private WebElement ele_two_one;
	
	@AndroidFindBy(xpath= "//android.view.ViewGroup[@content-desc=\"drag-c2\"]/android.widget.ImageView")
	private WebElement ele_two_two;
	
	@AndroidFindBy(xpath= "//android.view.ViewGroup[@content-desc=\"drag-r2\"]/android.widget.ImageView")
	private WebElement ele_two_three;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-l3\"]/android.widget.ImageView")
	private WebElement ele_three_one;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-c3\"]/android.widget.ImageView")
	private WebElement ele_three_two;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"drag-r3\"]/android.widget.ImageView")
	private WebElement ele_three_three;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Drag-drop-screen\"]/android.widget.ImageView")
	private WebElement cngrts;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Drag-drop-screen\"]/android.view.ViewGroup[1]/android.widget.TextView")
	private WebElement youmadeit;
	
	public void clickDrag() {
		drag.click();
	}
	
	public void dragElement1() {
		dragAction(ele_one_one, driver, 283, 669);
	}
	
	public void dragElement2() {
		dragAction(ele_one_two, driver, 563, 669);
	}
	
	public void dragElement3() {
		dragAction(ele_one_three, driver, 739, 669);
	}
	
	public void dragElement4() {
		dragAction(ele_two_one, driver, 283, 890);
	}
	
	public void dragElement5() {
		dragAction(ele_two_two, driver, 563, 890);
	}
	
	public void dragElement6() {
		dragAction(ele_two_three, driver, 739, 890);
	}
	
	public void dragElement7() {
		dragAction(ele_three_one, driver, 283, 1121);
	}
	
	public void dragElement8() {
		dragAction(ele_three_two, driver, 563, 1121);
	}
	
	public void dragElement9() {
		dragAction(ele_three_three, driver, 739, 1121);
	}
	
	public boolean cngrtsDisplayed() {
		return cngrts.isDisplayed();
	}
	
	public boolean youMadeItDisplayed() {
		return youmadeit.isDisplayed();
	}
	
	
	
	
	
	

}
