package POM;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MessagesPage {

	public AndroidDriver driver;

	public MessagesPage(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Got it\")")
	public WebElement gotItButton;

	@AndroidFindBy(accessibility = "Start chat")
	public WebElement startChatButton;

	@AndroidFindBy(className = "android.widget.MultiAutoCompleteTextView")
	public WebElement multiAutoCompleteTextView;
	
	@AndroidFindBy(uiAutomator="new UiSelector().text(\"Type a name, phone number, or email\")")
	public WebElement text;


	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Text message\")")
	public WebElement textMessageField;

	@AndroidFindBy(accessibility = "Send SMS")
	public WebElement sendSmsButton;

	public void clickGotIt() {
		gotItButton.click();
	}

	public void clickStartChat() {
		startChatButton.click();
	}
/*
	public void enterPhoneNumber(String phoneNumber) {
		multiAutoCompleteTextView.sendKeys(phoneNumber);
	}
*/
	public void enterPhoneNumber(String phoneNumber) {
		text.sendKeys(phoneNumber);
	}
	public void sendMessage(String message) {
		textMessageField.sendKeys(message);
		
		sendSmsButton.click();
	}
	/*
	public String getEnteredPhoneNumber() {
	    return multiAutoCompleteTextView.getText();
	}
	*/
	
	public String getEnteredPhoneNumber() {
		//Thread.sleep(3000);
	    return text.getText();
	}
	
	
	

}
