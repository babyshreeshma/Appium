package TestCase;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import POM.MessagesPage;
import base.BaseTest;

import java.net.MalformedURLException;

public class MessagesTest extends BaseTest {

    private MessagesPage messagesPage;

    @BeforeMethod
    public void setUpTest() throws MalformedURLException {
        setUp();
        messagesPage = new MessagesPage(driver);
    }
  

    @Test
    public void messageTest() {
        messagesPage.clickGotIt();
        messagesPage.clickStartChat();
        messagesPage.enterPhoneNumber("9746796445");
        driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
        messagesPage.sendMessage("Hello");
      //  Assert.assertEquals(messagesPage.getEnteredPhoneNumber(), "9746796445", "Assertion failed: Incorrect phone number entered");
      
    
    }
    
    @AfterMethod
    public void tearDownTest() {
        tearDown();
    }
}
