package com.appium;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class TrialTestCase1 extends BaseTest{
	@Test
	public void wifiSettingsTest() {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Radio Group\"))"));
		driver.findElement(AppiumBy.accessibilityId("Radio Group")).click();
		driver.findElement(AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[1]")).click();
		driver.findElement(AppiumBy.accessibilityId("Clear")).click();
	
	}


}
