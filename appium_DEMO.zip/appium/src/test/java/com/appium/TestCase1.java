package com.appium;

import io.appium.java_client.AppiumBy;
import org.testng.annotations.Test;
public class TestCase1 extends BaseTest{
	@Test
	
	public void wifiSettingsTest() {
		driver.findElement(AppiumBy.accessibilityId("Preference")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]")).click();
		driver.findElement(AppiumBy.id("android:id/checkbox")).click();
		}

}
