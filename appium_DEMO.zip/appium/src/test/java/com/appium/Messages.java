package com.appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class Messages {
	
	public AndroidDriver driver;
	@Test
	
	public void messageTest() throws MalformedURLException{
		DesiredCapabilities capabilities=new DesiredCapabilities();
		
		//set desired capabilities for the Android device or emulator
		
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "SreeshmasPhone");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.google.android.apps.messaging");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.google.android.apps.messaging.ui.ConversationListActivity");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723 "),capabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Got it\")")).click();
		
		driver.findElement(AppiumBy.accessibilityId("Start chat")).click();
		
		driver.findElement(AppiumBy.className("android.widget.MultiAutoCompleteTextView")).sendKeys("9746796445");

		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
		
		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Text message\")")).sendKeys("Hello");
		//driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
		driver.findElement(AppiumBy.accessibilityId("Send SMS")).click();
		
		
		
		}

}
