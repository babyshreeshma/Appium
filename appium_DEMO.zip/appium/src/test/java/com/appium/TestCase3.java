package com.appium;

import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

public class TestCase3  extends BaseTest{
	@Test
	
	public void dragAndDropTest() throws MalformedURLException,InterruptedException{
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Drag and Drop")).click();
		
		WebElement droppedElement1=driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1"));
		
		((JavascriptExecutor)driver).executeScript("mobile: dragGesture",ImmutableMap.of(
				"elementId",((RemoteWebElement)droppedElement1).getId(),
				"endX",647,
				"endY",580
				));
		Thread.sleep(3000);
		
		// After the drag and drop actions, you can assert the final positions
      
        Assert.assertEquals(droppedElement1.getLocation().getX(), 647);
        Assert.assertEquals(droppedElement1.getLocation().getY(), 580);

       
		
		WebElement droppedElement2=driver.findElement(By.id("io.appium.android.apis:id/drag_dot_2"));
		
		((JavascriptExecutor)driver).executeScript("mobile: dragGesture",ImmutableMap.of(
				"elementId",((RemoteWebElement)droppedElement2).getId(),
				"endX",817,
				"endY",821
				));
		
		Thread.sleep(3000);
		
		 Assert.assertEquals(droppedElement2.getLocation().getX(), 817);
	     Assert.assertEquals(droppedElement2.getLocation().getY(), 821);

		}
	
}



