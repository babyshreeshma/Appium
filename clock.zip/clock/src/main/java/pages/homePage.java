package pages;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class homePage extends AndroidActions {
	AndroidDriver driver;

	public homePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Alarm\"]/android.widget.FrameLayout/android.widget.ImageView")
	public WebElement alarm;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Clock\"]/android.widget.FrameLayout/android.widget.ImageView")
	public WebElement clock;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Timer\"]/android.widget.FrameLayout/android.widget.ImageView")
	public WebElement timer;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Stopwatch\"]/android.widget.FrameLayout/android.widget.ImageView")
	public WebElement stopWatch;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Bedtime\"]/android.widget.FrameLayout/android.widget.ImageView")
	public WebElement bedTime;
	
	@AndroidFindBy(xpath="//androidx.cardview.widget.CardView[@content-desc=\" Alarm\"])[1]/android.view.ViewGroup/android.widget.Switch")
	public WebElement setAlarm1;
	
	@AndroidFindBy(accessibility="Add alarm")
	private WebElement addAlarm;
	

	public void clickalarm() {
		alarm.click();
	}

	public void clickClock() {
		clock.click();
	}

	public void clickTimer() {
		timer.click();
	}

	public void clickStopWatch() {
		stopWatch.click();
	}

	public void clickBedTime() {
		bedTime.click();
	}

	// Inside homePage class
	public boolean isAlarmDisplayed() {
			return alarm.isDisplayed();
		
	}
	
	public void clickAddAlaram() {
		addAlarm.click();
	}

}
