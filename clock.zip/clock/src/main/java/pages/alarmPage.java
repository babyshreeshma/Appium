package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class alarmPage extends AndroidActions {
	AndroidDriver driver;

	public alarmPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(xpath="//android.widget.TextView[@content-desc=\"6 o'clock\"]")
	private WebElement alarmOnSix;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_clock_period_am_button")
	private WebElement am;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_timepicker_ok_button")
	private WebElement ok;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/day_button_3")
	private WebElement wednessday;
	
	
	@AndroidFindBy(id="com.google.android.deskclock:id/edit_label")
	private WebElement addLabel;
	
	
	@AndroidFindBy(id="com.google.android.deskclock:id/textinput_placeholder")
	private WebElement editLabel;
	
	@AndroidFindBy(id="android:id/button1")
	private WebElement okLabel;
	
	@AndroidFindBy(accessibility="Collapse alarm")
	private WebElement collapse;
	
	public void clickSix() {
		alarmOnSix.click();
	}
	
	public void clickAM() {
		am.click();
	}
	
	public void clickOk() {
		ok.click();
	}
	
	public void chooseWednessday() {
		wednessday.click();
	}
	
	public boolean isWdnsdyIsPresent() {
		return wednessday.isDisplayed();
	}
	
	public void clickAddLabel() {
		addLabel.click();
	}
	
	public void setAlarmLabel(String name) {
		editLabel.sendKeys(name);
		
	}
	
	public void clickOkLabel() {
		okLabel.click();
	}
	
	public void clickCollapse() {
		collapse.click();
	}
	
	
	
	
	


}
