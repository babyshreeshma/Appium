package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class timerPage extends AndroidActions {
	AndroidDriver driver;

	public timerPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(xpath= "//android.widget.FrameLayout[@content-desc=\"Timer\"]/android.widget.FrameLayout/android.widget.ImageView")
	private WebElement timer;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/timer_setup_digit_5")
	private WebElement five;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/timer_setup_time")
	private WebElement tmr;
	
	@AndroidFindBy(accessibility="Start")
	private WebElement startTmr;
	
	@AndroidFindBy(accessibility="Delete")
	private WebElement dltTmr;
	
	
	
	
	public void clickTimer() {
		timer.click();
	}

	public void chooseFive() {
		five.click();
	}
	
	public String getTimer() {
		return tmr.getText();
	}
	
	public void clickStartTmr() {
		startTmr.click();
	}
	public boolean timerDeleteDisplayed() {
		return dltTmr.isDisplayed();
	}
	
	public void clickDlt() {
		dltTmr.click();
	}
	
	
}
