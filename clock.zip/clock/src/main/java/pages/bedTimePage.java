package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class bedTimePage extends AndroidActions {
	AndroidDriver driver;

	public bedTimePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(accessibility="Bedtime")
	private WebElement bedTime;
	
//	@AndroidFindBy(uiAutomator="new UiSelector().text(\"Get Started\")")
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup")
	private WebElement getStarted;
	
	@AndroidFindBy(accessibility="Sunday")
	private WebElement sunday;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.widget.CheckBox")
	private WebElement vibrate;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/bedtime_onboarding_next\r\n")
	private WebElement next;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/bedtime_onboarding_done")
	private WebElement done;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/androidx.cardview.widget.CardView[1]/android.widget.LinearLayout/android.widget.LinearLayout")
	private WebElement isDone;
	public void clickBedTime() {
		bedTime.click();
	}
	
	public void clickGetStarted() {
		getStarted.click();
	}
	
	public void clickSunday() {
		sunday.click();
	}
	
	public boolean checkSundayIsDisplayed() {
	return sunday.isDisplayed();
	}
	
	public void clickVibrate() {
		vibrate.click();
	}
	
	public void clickNext() {
		next.click();
	}
	
	public void clickDone() {
		done.click();
	}
	
	public boolean checkIsDoneIsDisplayed() {
		return isDone.isDisplayed();
	}
	
	
}
