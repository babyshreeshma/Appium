package testcases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.alarmPage;
import pages.bedTimePage;
import pages.homePage;
import pages.timerPage;

@Listeners(utilities.SampleListener.class)
public class homePageTest extends BaseTest{  
	
	@DataProvider(name = "alarm")
	public Object[][] provideData() throws IOException {
		// Load alarm label data from a JSON file
		List<HashMap<String, String>> data = getJsonData(System.getProperty("user.dir") + "\\test\\java\\testcases\\alarm.json");
		// Prepare the test data array
		Object[][] testData = new Object[data.size()][1];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("name");
			
		}
		return testData;
	}

	
	    @Test(priority=0)
	    public void alarmTest() {	
	    	homePage hmpg=new homePage(driver);
	    	alarmPage alm=new alarmPage(driver);
	    	Assert.assertTrue(hmpg.isAlarmDisplayed(), "Assertion failed: Expected element is not displayed after clicking alarm.");
	    	hmpg.clickalarm();
	    	hmpg.clickAddAlaram();
	    	alm.clickSix();
	    	alm.clickAM();
	    	alm.clickOk();
	    	alm.chooseWednessday();
	    	//Check alarm is set 
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(alm.isWdnsdyIsPresent()).isTrue();
			});
	    	
			//alm.clickAddLabel();
	    	//alm.setAlarmLabel("alarm1");
	    	//alm.clickOkLabel();
	    	alm.clickCollapse();
	    	
	    	SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(alm.isWdnsdyIsPresent()).isFalse();
			});
	    	
	    	
	    	
	    	
	    
	    }
	    
	    @Test(priority=1)
	    public void timerTest() {
	    	timerPage tmr=new timerPage(driver);
	    	tmr.clickTimer();
	    	tmr.chooseFive();
	    		
	    	String expected = tmr.getTimer();
			System.out.println(expected);
			String actual ="00h 00m 05s" ;
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
			});
			
			tmr.clickStartTmr();
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(tmr.timerDeleteDisplayed()).isTrue();
			});

			tmr.clickDlt();
		
	    }
	    
	    @Test(priority=2)
	    public void bedTimeTest() {
	    	bedTimePage btp= new bedTimePage(driver);
	    	btp.clickBedTime();
	    	btp.clickGetStarted();
	    	
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(btp.checkSundayIsDisplayed()).isTrue();
			});
	    	
	    	btp.clickSunday();
	    	btp.clickVibrate();
	    	btp.clickNext();
	    	btp.clickDone();
	    	SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(btp.checkIsDoneIsDisplayed()).isTrue();
			});
	    	
	    }
	    
	    
	   
}
