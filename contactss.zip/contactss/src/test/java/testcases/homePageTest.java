package testcases;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import pages.homePage;
import utilities.SampleListener;


@Listeners(utilities.SampleListener.class)

public class homePageTest extends BaseTest{
	
	
	//Reading data drom json file
	@DataProvider(name="contact")
	public Object[][] contactdata() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "/src/test/java/testData/contact.json");
		Object[][] testData = new Object[data.size()][6];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("Firstname");
			testData[i][1] = row.get("Lastname");
			testData[i][2] = row.get("Companyname");
			testData[i][3] = row.get("Phone");
			testData[i][4] = row.get("Email");
			testData[i][5] = row.get("Message");
			}
		return testData;
		}
			
			@Test(dataProvider = "contact")
			public void contactTest(String fname,String lname,String company,String phone,String email,String message) {
				homePage hmpg=new homePage(driver);
				hmpg.skip1();
				hmpg.Allows();
				hmpg.clickCreate();
				hmpg.firstname(fname);
				
				
				hmpg.lastName(lname);
				hmpg.company(company);
				hmpg.phone(phone);
				hmpg.email(email);
				hmpg.clicksave();
				hmpg.clickSendText();
				hmpg.clickAndSendMsg(message);
				hmpg.clickSendSMS();
				
				String expectedfn = hmpg.getFirstname();
				String actualfn =fname;
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(expectedfn.equalsIgnoreCase(actualfn)).isTrue();
				});
			
				//Check search button
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(hmpg.checkSearchBtnIsPresent()).isTrue();
				});
				
				//Check message is send or not
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(hmpg.checkMessageIsPresent()).isTrue();
				});
				
				
				
			}

	    
	   
}
