package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class homePage extends AndroidActions {
	AndroidDriver driver;

	public homePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		// TODO Auto-generated constructor stub
	}

	@AndroidFindBy(id = "android:id/button2")
	private WebElement skip;

	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	private WebElement allow;

	@AndroidFindBy(id = "com.google.android.contacts:id/floating_action_button")
	private WebElement createContact;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"First name\")")
	private WebElement firstname;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Last name\")")
	private WebElement lastname;
		

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Company\")")
	private WebElement company;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Phone\")")
	private WebElement phone;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Email\")")
	private WebElement email;

	@AndroidFindBy(id = "com.google.android.contacts:id/toolbar_button")
	private WebElement save;

	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Text\"]")
	private WebElement text;

	@AndroidFindBy(id = "com.google.android.apps.messaging:id/compose_message_text")
	private WebElement entermsg;

	@AndroidFindBy(accessibility="Send SMS")
	private WebElement sendsms;
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Search\"]")
	private WebElement search;
	
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Hello\")")
	private WebElement hellomsg;
			
	public void skip1() {
		skip.click();
	}

	public void Allows() {
		allow.click();
	}

	public void clickCreate() {
		createContact.click();
	}

	public void firstname(String fname) {
		firstname.sendKeys(fname);
	}
	
	public String getFirstname() {
		return firstname.getText();
	}

	public void lastName(String lname) {
		lastname.sendKeys(lname);
	}

	public void company(String cmp) {
		company.sendKeys(cmp);
	}

	public void phone(String phn) {
		phone.sendKeys(phn);
	}

	public void email(String em) {
		email.sendKeys(em);
	}

	public void clicksave() {
		save.click();
	}

	public void clickSendText() {
		text.click();
	}

	public void clickAndSendMsg(String msg) {
		entermsg.sendKeys(msg);
	}
	
	public void clickSendSMS() {
		sendsms.click();
	}
	
	
	public String checkCompanyName() {
		return company.getText();
	}
	
	public void clickSearch() {
		search.click();
	 }
	
	public boolean checkSearchBtnIsPresent() {
		return search.isDisplayed();
	}
	
	public boolean checkMessageIsPresent() {
		return hellomsg.isDisplayed();
	}
	
	
	

}
