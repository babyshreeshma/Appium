package utilities;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.appium.java_client.android.AndroidDriver;

public class ExtentReportManager extends AndroidActions{

	public ExtentReportManager(AndroidDriver driver) {
		super(driver);
	}
	
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + AndroidActions.timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Sreeshma");
		spark.config().setDocumentTitle("Contact Report");
		// Name of the report
		spark.config().setReportName("Contact Report");
		// Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}
	
	

}
