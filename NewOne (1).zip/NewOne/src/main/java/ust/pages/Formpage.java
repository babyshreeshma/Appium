package ust.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import ust.base.AndroidActions;

public class Formpage extends AndroidActions{

	
	public Formpage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		
	}
	
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"Enter name here\")")
	private WebElement nameField;

	
	@AndroidFindBy(xpath="//android.widget.RadioButton[@text='Female']")
	private WebElement femaleOption;
	//driver.findElement(By.xpath("//android.widget.RadioButton[@text='Female']"))
	
	@AndroidFindBy(xpath="//android.widget.RadioButton[@text='Male']")
	private WebElement maleOption;
	
	@AndroidFindBy(id = "android:id/text1")
	private WebElement countrySelection;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement shopButton;
	
	
	@AndroidFindBy(xpath="//android.widget.RelativeLayout[2]//android.widget.LinearLayout//android.widget.LinearLayout[2]")
	private WebElement shoe;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/appbar_btn_cart")
	private WebElement cart;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"$ 120.0\")")
	private WebElement rate;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"General Store\")")
	private WebElement title;
	
	@AndroidFindBy(xpath ="android.widget.RelativeLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout[2]")
	private WebElement shoe2;
	
	@AndroidFindBy(xpath ="//android.widget.RelativeLayout[3]//android.widget.LinearLayout//android.widget.ImageView")
	private WebElement prod3;

	
	public void setNameField(String name)
	{
		nameField.sendKeys(name);
		driver.hideKeyboard();
		
	}

	
	public void setGender(String gender)
	{	
		if (gender.contains("female"))
			femaleOption.click();
		else
			maleOption.click();
			
	}
	
	public void setCountrySelection(String countryName)
	
	{
		countrySelection.click();
		scrollToText(countryName);
		driver.findElement(By.xpath("//android.widget.TextView[@text='"+countryName+"']")).click();
		
	}
	
	public void shopBtnClick() {
		shopButton.click();
	}
	
	public void shoeClick() {
		shoe.click();
	}
	public void cartClick() {
		cart.click();
	}
 public String getTitle() {
	return title.getText();
 }

	public String productPrice() {
		return rate.getText();
	}
	public void product2Click() {
		shoe2.click();
	}
	
}
