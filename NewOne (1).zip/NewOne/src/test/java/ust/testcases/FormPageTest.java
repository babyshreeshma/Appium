package ust.testcases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ust.base.Basetest1;
import ust.pages.Formpage;
import ust.util.Excelutils;

public class FormPageTest extends Basetest1{

		String[][] data;
		
		//Method to get the value from excel
		@DataProvider(name = "logData")
		public Object[][] testdata(){
			data= Excelutils.testdata();
			return data;
		}
	
	@Test(priority=1,dataProvider="logData")
	public void test1(String name,String gend,String count) {
		Formpage f1=new Formpage(Basetest1.driver);

		f1.setNameField(name);
		f1.setGender(gend);
		f1.setCountrySelection(count);
		f1.shopBtnClick();
		f1.shoeClick();
		f1.cartClick();
		
}
}
