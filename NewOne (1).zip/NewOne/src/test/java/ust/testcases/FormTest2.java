package ust.testcases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import ust.base.Basetest1;
import ust.pages.Formpage;

@Listeners(ust.util.SampleListener.class)
public class FormTest2 extends Basetest1{

	
	@DataProvider(name="getData")
	public Object[][] getData() throws IOException
	{
		List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\test\\java\\testdata\\formd.json");
		Object[][] testData = new Object[data.size()][3];

	    for (int i = 0; i < data.size(); i++) {
	        HashMap<String, String> row = data.get(i);
	        testData[i][0] = row.get("name");
	        testData[i][1] = row.get("gender");
	        testData[i][2] = row.get("country");
	    }

	    return testData;
	}

@Test(priority=1,dataProvider="getData")
public void test1(String name,String gender,String country) {
	Formpage f1=new Formpage(Basetest1.driver);
	String t1=f1.getTitle();
	
	//verify general store text is displayed
	 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(t1.equalsIgnoreCase("General Store"));
	 });
	 
	 SoftAssertions.assertSoftly(softAssertions -> {
	       softAssertions.assertThat(driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).isDisplayed());
					
		});
	
	SoftAssertions.assertSoftly(softAssertions -> {
	       softAssertions.assertThat(driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).isDisplayed());
					
		});
	
	f1.setNameField(name);
	f1.setGender(gender);
	f1.setCountrySelection(country);
	f1.shopBtnClick();
	
	//verify Products text is displayed
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(AppiumBy.androidUIAutomator("UiSelector().text(\"Products\")")).isDisplayed());
						
			});
	
	f1.shoeClick();
	f1.cartClick();
	
	//verify cart field is present or not
	SoftAssertions.assertSoftly(softAssertions -> {
	       softAssertions.assertThat(driver.findElement(AppiumBy.androidUIAutomator("UiSelector().text(\"Cart\")")).isDisplayed());
					
		});
	
	 System.out.println(f1.productPrice());
		String expected = f1.productPrice();
		 String actual = "$ 120.0";
		 
		//verify rate field is correct or not
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
		 });
	
}
	
}
