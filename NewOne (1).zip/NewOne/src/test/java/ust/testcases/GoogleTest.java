package ust.testcases;

import org.testng.annotations.Test;

import ust.base.Basetest2;
import ust.pages.GooglePage;

public class GoogleTest extends Basetest2 {

	@Test
	public void google() throws InterruptedException {
		GooglePage g1=new GooglePage(driver);
		g1.accept();
		g1.acceptno();
		Thread.sleep(20000);
	}
}
