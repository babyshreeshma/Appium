package utilities;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


public class SampleListeners extends TestListenerAdapter {

	public static ExtentReports extent;
	public static ExtentTest logger;

	/****************
	 * Getting extent report instance on start of test class
	 ********/
	public void onStart(ITestContext context) {
		extent = ExtentReportManagerContacts.getReportInstance();
	}

	/*************
	 * creating test in extent report on start of each test
	 **************/
	public void onTestStart(ITestResult result) {
		logger = extent.createTest(result.getName());
		AndroidActionsContacts.logger = logger;
	}

	public void onTestSuccess(ITestResult result) {
		logger.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		logger.log(Status.PASS, "Testcase Passed");
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots//" + folderName + "/" + testName
				+ "/" + testName + "_Passed.png";
		try {
			AndroidActionsContacts.takeScreenShot(filepath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onTestFailure(ITestResult result) {
		logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
		logger.log(Status.FAIL, "Testcase Failed");
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots//" + folderName + "/" + testName
				+ "/" + testName + "_Failed.png";
		try {
			AndroidActionsContacts.takeScreenShot(filepath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onTestSkip(ITestResult tr) {
		logger = extent.createTest(tr.getName());
		logger.log(Status.SKIP, MarkupHelper.createLabel(tr.getName(), ExtentColor.YELLOW));
		logger.log(Status.SKIP, "Testcase Skipped");

	}

	/*************************
	 * Flushing teh extent report at the end of the test class
	 **************/
	public void onFinish(ITestContext testContext) {
		extent.flush();
	}
}
