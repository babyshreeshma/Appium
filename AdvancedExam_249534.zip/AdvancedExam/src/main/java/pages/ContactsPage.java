package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActionsContacts;

public class ContactsPage extends AndroidActionsContacts {

	AndroidDriver driver;
	public ContactsPage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}
	
	@AndroidFindBy(id ="android:id/button2")
	private WebElement skipbtn;
	
	@AndroidFindBy(id ="com.android.permissioncontroller:id/permission_allow_button")
	private WebElement allowbtn;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/floating_action_button")
	private WebElement createcontactbtn;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"First name\")")
	private WebElement firstname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Last name\")")
	private WebElement lasttname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Company\")")
	private WebElement company;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Phone\")")
	private WebElement phone;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Email\")")
	private WebElement email;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/toolbar_button")
	private WebElement savebtn;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/large_title")
	private WebElement fullname;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/organization_name")
	private WebElement companyname;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/floating_action_button")
	private WebElement editbtn;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/verb_text")
	private WebElement textbtn;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/menu_star")
	private WebElement fav;
	
	@AndroidFindBy(id ="com.google.android.apps.messaging:id/compose_message_text")
	private WebElement txtmsgbox;
	
	@AndroidFindBy(id ="com.google.android.apps.messaging:id/send_message_button_icon")
	private WebElement sndbtn;
	
	public void clickSkip() {
		skipbtn.click();
	}
	
	public void clickAllow() {
		allowbtn.click();
	}
	
	public void clickCreate() {
		createcontactbtn.click();
	}
	
	public void enterFirstName(String fname) {
		firstname.sendKeys(fname);
	}
	
	public void enterLastName(String lname) {
		lasttname.sendKeys(lname);
	}
	
	public void enterCompanyName(String cmp) {
		company.sendKeys(cmp);
	}
	
	public void enterPhoneNumber(String ph) {
		phone.sendKeys(ph);
	}
	
	public void enterEmail(String em) {
		email.sendKeys(em);
	}
	
	public void clickSave() {
		savebtn.click();
	}
	
	public String checkFullName() {
		return fullname.getText();
	}
	
	public String checkCompanyName() {
		return companyname.getText();
	}
	
	public boolean checkEditBtnPresent() {
		return editbtn.isDisplayed();
	}
	
	public boolean checkTextBtnPresent() {
		return textbtn.isDisplayed();
	}
	
	public boolean checkFavoritesBtnPresent() {
		return fav.isDisplayed();
	}
	
	public void clickTextBtn() {
		textbtn.click();
	}
	
	public void enterMessage(String msg) {
		txtmsgbox.sendKeys(msg);
	}
	
	public void clickSendBtn() {
		sndbtn.click();
	}

}
