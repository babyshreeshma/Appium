package testcases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseContacts;
import pages.ContactsPage;

@Listeners(utilities.SampleListeners.class)

public class ContactTests extends BaseContacts{
	
	//Reading data drom json file
	@DataProvider(name="contactdata")
	public Object[][] contactdata() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "/src/test/java/testdata/contact.json");
		Object[][] testData = new Object[data.size()][6];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("Firstname");
			testData[i][1] = row.get("Lastname");
			testData[i][2] = row.get("Companyname");
			testData[i][3] = row.get("Phone");
			testData[i][4] = row.get("Email");
			testData[i][5] = row.get("Message");
			}
		return testData;
		}
	
	@Test(dataProvider = "contactdata")
	public void contactTest(String fn,String ln,String cn,String ph,String em,String msg) {
		
		ContactsPage csp = new ContactsPage(driver);
		csp.clickSkip();
		csp.clickAllow();
		csp.clickCreate();
		csp.enterFirstName(fn);
		csp.enterLastName(ln);
		csp.enterCompanyName(cn);
		csp.enterPhoneNumber(ph);
		csp.enterEmail(em);
		csp.clickSave();
		
		//Checking full name of contact
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat((fn+" "+ln).equalsIgnoreCase(csp.checkFullName())).isTrue();
		});
		
		//Checking company name
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(cn.equalsIgnoreCase(csp.checkCompanyName())).isTrue();
		});
		
		//Check edit btn
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(csp.checkEditBtnPresent()).isTrue();
		});
		
		//checking add to fav btn
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(csp.checkFavoritesBtnPresent()).isTrue();
		});
		
		//Checking textmessage btn 
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(csp.checkTextBtnPresent()).isTrue();
		});
		
		csp.clickTextBtn();
		csp.enterMessage(msg);
		csp.clickSendBtn();
		
		
	}
	

}
